/*-------------------------------------------------------------------------
 *
 * distfuncs.h
 *
 * Copyright (c) 2018, PipelineDB, Inc.
 *
 *-------------------------------------------------------------------------
 */
#ifndef DISTFUNCS_H
#define DISTFUNCS_H

#include "postgres.h"
#include "fmgr.h"

#define TDIGEST_TYPENAME "tdigest"

#endif
