-- citus--8.2-1--8.2-2.sql
DROP FUNCTION IF EXISTS pg_catalog.create_insert_proxy_for_table(regclass,regclass);
